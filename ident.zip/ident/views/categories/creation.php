<div class='row'>
    <h1 class='col-md-12 text-center border border-dark bg-primary text-white'>Ajouter une catégorie</h1>
</div>
<div class='row'>
    <form method='post' action=''>
  
        <div class='form-group my-3'>
            <label for='text'>Nom catégorie</label>
            <input type='text' name='nom_cat' class='form-control' id='nom_cat' placeholder='Enter nom de la catégorie' required autofocus>
        </div>
       <button type='submit' class='btn btn-primary my-3' name='submit'>Ajouter la catégorie</button>
    </form>
</div>